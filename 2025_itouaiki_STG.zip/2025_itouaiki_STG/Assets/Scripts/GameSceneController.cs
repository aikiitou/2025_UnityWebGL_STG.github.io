using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;
public class GameSceneController : MonoBehaviour
{
    [SerializeField] private GameObject ClearObject = null;
    [SerializeField] private GameObject FailedObject = null;
    // Start is called before the first frame update
    void Start()
    {
        ClearObject.SetActive(false);
        FailedObject.SetActive(false);
    }

    public void Failed()
    {
        FailedObject.SetActive(true);
        StartCoroutine(ChangeScene("StartScene"));
    }
    public void Cleared()
    {
        ClearObject.SetActive(true);
        StartCoroutine(ChangeScene("StartScene"));
    }
    IEnumerator ChangeScene(string scene_name)
    {
        yield return new WaitForSeconds(5.0f);
        SceneManager.LoadScene(scene_name);
    }
}
