using UnityEngine;

public class Enemy01 : MonoBehaviour
{
    private const float SPEED = 4.0f;
    private GameObject CountObject = null;
    private Vector3 Direction = new Vector3(-1.0f,0.0f,0.0f);
    private Vector3 Velocity;
    private Rigidbody2D rb;
    private SpriteRenderer sr;
    private bool arrive = false;

    // Start is called before the first frame update
    void Start()
    {
        CountObject = GameObject.Find("EnemiesFactory");
        rb= GetComponent<Rigidbody2D>();
        sr = GetComponent<SpriteRenderer>();
    }

    // Update is called once per frame
    void Update()
    {
        if(sr.isVisible)
        {
            arrive = true;
        }
        if(!sr.isVisible && arrive)
        {
            Destroy(gameObject);
        }
        Velocity = Direction.normalized * SPEED;
    }
    private void FixedUpdate()
    {
        rb.velocity = Velocity;
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (arrive == true && collision.gameObject.tag == "Bullet" || collision.gameObject.tag == "Player")
        {
            CountObject.GetComponent<EnemiesFactory>().defeat();
            Instantiate(Resources.Load("Prefabs/Explosion"), transform.position, Quaternion.identity);
            Destroy(gameObject);
        }
    }
}
