using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemController : MonoBehaviour
{
    private Vector3 Direction;
    private Vector3 Velocity;
    private Rigidbody2D rb;
    private SpriteRenderer sr;
    private bool isArrive = false;
    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        sr = GetComponent<SpriteRenderer>();
    }

    // Update is called once per frame
    void Update()
    {
        Direction = new Vector3(-1.0f, 0.0f, 0.0f);
        Direction.Normalize();
        Velocity = Direction;
        if (sr.isVisible)
        {
            isArrive = true;
        }
        if (!sr.isVisible && isArrive)
        {
            Debug.Log("����");
            Destroy(gameObject);
        }
    }
    void FixedUpdate()
    {
        rb.velocity = Velocity;
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.gameObject.tag == "Player")
        {
            Destroy(gameObject);
        }
    }
}
