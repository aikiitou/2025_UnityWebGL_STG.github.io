using UnityEngine;

public class ItemDrop : MonoBehaviour
{
    public void Drop()
    {
        int value;
        value = Random.Range(0, 100);
        if(value < 50)
        {
            int item_num;
            item_num = Random.Range(0, 100);
            if(item_num < 70)
            {
                Instantiate(Resources.Load("Prefabs/Shield_Item"),transform.position,Quaternion.identity);
            }
            else
            {
                Instantiate(Resources.Load("Prefabs/Life_Item"), transform.position, Quaternion.identity);
            }
        }
        else
        {
            return;
        }
    }
}
