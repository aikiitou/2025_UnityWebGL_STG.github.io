using System.Collections;
using UnityEngine;

public class BossController : MonoBehaviour
{
    public enum ActionPart
    {
        Appearance,     //�o���p�[�g
        Battle,         //�퓬�p�[�g
        Defeat,         //���ރp�[�g
    }

    private const float SPEED = 2.0f;
    private const float POS_Y_UP = 1.5f;
    private const float POS_Y_HOME = 0.0f;
    private const float POS_Y_DOWN = -2.5f;
    private GameObject SceneManagerObject = null;
    private GameObject FirePoint = null;
    private ActionPart CurrentPart = ActionPart.Appearance;
    private Rigidbody2D rb;
    private Renderer render;
    private Vector3 Direction;
    private Vector3 Velocity;
    private Vector3 FirePos;
    private int HitPoint = 10;
    private int PosNum;
    private int CurrentNum;
    private bool isDefeat = false;
    private bool isInterval = false;

    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        render = GetComponent<Renderer>();
        SceneManagerObject = GameObject.Find("GameSceneManager");
        FirePoint = GameObject.Find("FirePoint");
    }

    // Update is called once per frame
    void Update()
    {
        switch (CurrentPart)
        {
            case ActionPart.Appearance:
                {
                    appearance();
                    break;
                }
            case ActionPart.Battle:
                {
                    battle();
                    break;
                }
            case ActionPart.Defeat:
                {
                    Direction = new Vector3(0.1f, -1.0f, 0.0f);
                    if (!render.isVisible)
                    {
                        SceneManagerObject.GetComponent<GameSceneController>().Cleared();
                        Destroy(gameObject);
                    }
                    if (isDefeat) return;
                    else
                    {
                        StartCoroutine(defeat());
                    }
                    break;
                }
        }
        Direction.Normalize();
        Velocity = Direction * SPEED;
    }
    private void FixedUpdate()
    {
        rb.velocity = Velocity;
    }

    private void appearance()
    {
        if (transform.position.x > 3.4)
        {
            Direction = new Vector3(-1.0f, 0.0f, 0.0f);
        }
        else
        {
            Direction = Vector3.zero;
            CurrentPart = ActionPart.Battle;
        }
    }

    private void battle()
    {
        if (isInterval)
        {
            return;
        }
        else
        {
            PosNum = Random.Range(1, 101);
            if (PosNum <= 30)
            {
                StartCoroutine(move() );
            }
            else
            {
                StartCoroutine(bullet());
            }
        }
    }
    //�퓬���̍s���P�i�e�̔��ˁj
    private IEnumerator bullet()
    {
        isInterval = true;
        FirePos = FirePoint.transform.position;
        Instantiate(Resources.Load("Prefabs/BossBullet"), FirePos, Quaternion.identity);
        yield return new WaitForSeconds(1.0f);
        isInterval = false;
    }
    //�퓬���̍s���Q�i�ꏊ�̕ύX�j
    private IEnumerator move()
    {
        isInterval = true;
        RandomNum();
        switch (PosNum)
        {
            case 0:
                {
                    //�{�X�̏ꏊ��i�ւ̈ړ�
                    rb.MovePosition(new Vector3(transform.position.x, POS_Y_UP, transform.position.z));
                    break;
                }
            case 1:
                {
                    //�{�X�̏ꏊ���i�ւ̈ړ�
                    rb.MovePosition(new Vector3(transform.position.x, POS_Y_HOME, transform.position.z));
                    break;
                }
            case 2:
                {
                    //�{�X�̏ꏊ���i�ւ̈ړ�
                    rb.MovePosition(new Vector3(transform.position.x, POS_Y_DOWN, transform.position.z));
                    break;
                }
        }
        yield return new WaitForSeconds(1.0f);
        isInterval = false;
    }
    //�{�X�̈ړ��ꏊ�̃����_���I��
    private void RandomNum()
    {
        PosNum = Random.Range(0, 3);
        CurrentNum = PosNum;
    }
    private IEnumerator defeat()
    {
        isDefeat = true;
        Vector3 expos= Vector3.zero;
        while(render.isVisible)
        {
            expos.x = Random.Range(-2.5f, 2.5f);
            expos.y = Random.Range(-0.5f, 0.5f);
            Instantiate(Resources.Load("Prefabs/Explosion"), expos + transform.position , Quaternion.identity);
            yield return new WaitForSeconds(0.1f);
        }
        yield return null ;
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.gameObject.tag == "Bullet" && CurrentPart == ActionPart.Battle)
        {
            HitPoint--;
            if(HitPoint <= 0)
            {
                CurrentPart = ActionPart.Defeat;
            }
        }
    }
}