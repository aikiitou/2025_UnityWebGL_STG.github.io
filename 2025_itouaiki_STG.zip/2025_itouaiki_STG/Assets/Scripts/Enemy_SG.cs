using UnityEngine;

public class Enemy_SG : MonoBehaviour
{
    private const float SPEED = 2.0f;
    private Rigidbody2D rb;
    private SpriteRenderer sr;
    private Vector3 Direction;
    private Vector3 Velocity;
    private GameObject CountObject = null;
    private bool isStop = false;
    private bool isArrive = false;
    private float timer;
    // Start is called before the first frame update
    void Start()
    {
        CountObject = GameObject.Find("EnemiesFactory");
        rb = GetComponent<Rigidbody2D>();
        sr = GetComponent<SpriteRenderer>();
    }

    // Update is called once per frame
    void Update()
    {
        if (sr.isVisible)
        {
            isArrive = true;
        }
        if (!sr.isVisible && isArrive)
        {
            Destroy(gameObject);
        }
        timer += Time.deltaTime;
        //��b���Ƃ�STOP��GO�̐؂�ւ�
        if(timer>1.0f)
        {
            if(isStop==true)
            {
                isStop = false;
                timer = 0.0f;
            }
            else
            {
                isStop = true;
                timer = 0.0f;
            }
        }
        //isStop��true�Ȃ��~
        if(isStop==true)
        {
            Direction = Vector3.zero;
        }
        //isStop��false�Ȃ�i��
        else
        {
            Direction = new Vector3(-1.0f, 0.0f, 0.0f);
        }
        Direction.Normalize();
        Velocity = Direction * SPEED;
    }
    private void FixedUpdate()
    {
        rb.velocity = Velocity;
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (isArrive == true && collision.gameObject.tag == "Bullet" || collision.gameObject.tag == "Player")
        {
            CountObject.GetComponent<EnemiesFactory>().defeat();
            GetComponent<ItemDrop>().Drop();
            Instantiate(Resources.Load("Prefabs/Explosion"), transform.position, Quaternion.identity);
            Destroy(gameObject);
        }
    }
}
