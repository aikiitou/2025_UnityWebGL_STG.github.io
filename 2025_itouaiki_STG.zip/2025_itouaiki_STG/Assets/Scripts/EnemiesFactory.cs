/*
    �d�l�F
        �E�Q�b�Ɉ�̐���
        �E�G�̐����ʒu��Y���|�R�`�R�܂�X��Z�͂��̂܂܂̈ʒu���g��
*/
using System.Collections;
using UnityEngine;

public class EnemiesFactory : MonoBehaviour
{
    private Vector3 Pos;
    private const int DEFEATCOUNT = 30;
    private const float INTERVALTIME = 2.0f;
    private int defeatcounter = 0;
    private float enemy_num = 0;
    // Start is called before the first frame update
    void Start()
    {
        StartCoroutine(Produce());
    }

    public void defeat()
    {
        defeatcounter++;
    }
    IEnumerator Produce()
    {
        while(defeatcounter < DEFEATCOUNT)
        {
            Pos = transform.position;
            Pos.y = Random.Range(-3.0f, 3.0f);
            enemy_num = Random.Range(0, 100);
            if(enemy_num < 60)
            {
                Instantiate(Resources.Load("Prefabs/Enemy01"), Pos, Quaternion.identity);
            }
            else if(enemy_num <100)
            {
                Instantiate(Resources.Load("Prefabs/Enemy_SG"), Pos, Quaternion.identity);
            }
            yield return new WaitForSeconds(INTERVALTIME);
        }
        Instantiate(Resources.Load("Prefabs/Boss"), transform.position, Quaternion.identity);
    }
}
