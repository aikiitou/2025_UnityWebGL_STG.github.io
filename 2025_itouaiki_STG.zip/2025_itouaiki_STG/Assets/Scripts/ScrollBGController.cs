using UnityEngine;

public class ScrollBGController : MonoBehaviour
{
    // Update is called once per frame
    void Update()
    {
        float speed = 3.0f * Time.deltaTime;

        transform.Translate(-speed, 0.0f, 0.0f);

        if (transform.position.x <= -12.8f)
        {
            transform.Translate(12.8f * 3.0f, 0.0f, 0.0f);
        }
    }
}
