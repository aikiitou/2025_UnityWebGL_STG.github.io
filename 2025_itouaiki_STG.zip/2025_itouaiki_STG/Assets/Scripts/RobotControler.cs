using System.Collections;
using UnityEngine;
public class RobotControler : MonoBehaviour
{
    private const float NORMALSPEED = 2.0f;
    private const float BOOST = 3.0f;
    private GameObject BulletPrefab = null;
    private GameObject SceneManagerObject = null;
    [SerializeField] private GameObject HitPointUI = null;
    private SpriteRenderer[] render = null;
    private Rigidbody2D rb = null;
    private Vector3 Direction;
    private Vector3 Velocity;
    private Vector3 Pos;
    private Vector3 FirePos;
    private Vector3 new_pos;
    private int HitPoint = 5;
    private float Invincibletimer = 0.0f;//0���傫���Ȃ疳�G
    private bool boostmode = false;
    private bool bullet_interval = false;
    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        render = GetComponentsInChildren<SpriteRenderer>();
        /*
            Resources.Load��Resources�t�H���_���̃t�H���_����I�u�W�F�N�g���Q�Ƃ���Ƃ��F
                Resources.Load("�t�H���_��/�I�u�W�F�N�g��")
        */
        BulletPrefab = Resources.Load("Prefabs/RobotBullet") as GameObject;

        //UI��Hitpoint�̏�����4
        HitPointUI.GetComponent<HitPointControllere>().UpdateHitPointUI(HitPoint);
        SceneManagerObject = GameObject.Find("GameSceneManager");
    }

    // Update is called once per frame
    void Update()
    {
        move();
        invincible();
        if (Input.GetKeyDown(KeyCode.Space) && !boostmode)
        {
            StartCoroutine(RunRedCometMode());
        }
        if (Input.GetKey(KeyCode.Z) && !bullet_interval)
        {
            StartCoroutine(BulletFire());
        }
    }
    private void FixedUpdate()
    {
        rb.velocity = Velocity;
    }
    private void LateUpdate()
    {
        new_pos = transform.position;
        new_pos.x = Mathf.Clamp(new_pos.x, -5.25f, 5.55f);
        new_pos.y = Mathf.Clamp(new_pos.y, -3.4f, 2.86f);
        transform.position = new_pos;
    }
    private void move()
    {
        Direction = Vector3.zero;
        if (Input.GetKey(KeyCode.UpArrow))
        {
            Direction.y = 1.0f;
        }
        if (Input.GetKey(KeyCode.DownArrow))
        {
            Direction.y = -1.0f;
        }
        if (Input.GetKey(KeyCode.LeftArrow))
        {
            Direction.x = -1.0f;
        }
        if (Input.GetKey(KeyCode.RightArrow))
        {
            Direction.x = 1.0f;
        }
        Direction.Normalize();
        if (!boostmode)
        {
            Velocity = Direction * NORMALSPEED;
        }
        else
        {
            Velocity = Direction * NORMALSPEED * BOOST;
        }
    }

    private void invincible()//enbled��(enbled�͌����邩�����Ȃ����̔���j
    {
        float timer = Invincibletimer % 0.5f;
        bool enbled;
        if (Invincibletimer > 0)
        {
            Invincibletimer -= Time.deltaTime;
            if (timer > 0.25f)
            {
                enbled = true;
            }
            else
            {
                enbled = false;
            }
            for (int i = 0; i < render.Length; i++)
            {
                render[i].enabled = enbled;
            }
        }
        else
        {
            for (int i = 0; i < render.Length; i++)
            {
                render[i].enabled = true;
            }
        }
    }

    IEnumerator RunRedCometMode()
    {
        boostmode = true;
        render[0].color = Color.red;
        yield return new WaitForSeconds(3.0f);

        boostmode = false;
        render[0].color = Color.white;
    }
    IEnumerator BulletFire()
    {
        Pos = transform.position;
        FirePos = new Vector3(Pos.x + 1, Pos.y, Pos.z);
        Instantiate(BulletPrefab, FirePos, Quaternion.identity);
        bullet_interval = true;
        yield return new WaitForSeconds(0.3f);
        bullet_interval = false;
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (Invincibletimer <= 0 &&(collision.tag == "Enemy"|| collision.tag == "Boss"))
        {
            HitPoint--;
            HitPointUI.GetComponent<HitPointControllere>().UpdateHitPointUI(HitPoint);
            if (HitPoint <= 0)
            {
                SceneManagerObject.GetComponent<GameSceneController>().Failed();
                Destroy(gameObject);
            }
            else
            {
                Invincibletimer = 2.0f;
            }
        }
        if(collision.tag == "Shield_Item")
        {
            Instantiate(Resources.Load("Prefabs/Shield"), transform.position, Quaternion.identity);
        }
        if(collision.tag == "Life_Item")
        {
            HitPoint++;
            if(HitPoint > 5)
            {
                HitPoint = 5;
            }
            HitPointUI.GetComponent<HitPointControllere>().UpdateHitPointUI(HitPoint);

        }
    }
}
