using UnityEngine;

public class RobotBulletControler: MonoBehaviour
{
    private const float SPEED = 8.0f;
    private Rigidbody2D rb;
    private Vector3 Direction;
    private Vector3 Velocity;
    // Start is called before the first frame update
    void Start()
    {
        rb= GetComponent<Rigidbody2D>();  
    }

    // Update is called once per frame
    void Update()
    {
        Direction = new Vector3(1.0f,0.0f,0.0f);
        Velocity = Direction.normalized * SPEED;
        if(!GetComponent<SpriteRenderer>().isVisible)
        {
            Destroy(gameObject);
        }
    }
    private void FixedUpdate()
    {
        rb.velocity = Velocity;
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.tag == "Enemy" || collision.tag == "Boss")
        {
            Destroy(gameObject);
        }
    }
}
